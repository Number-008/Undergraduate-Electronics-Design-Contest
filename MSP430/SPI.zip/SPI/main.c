#include "msp430g2553.h"
#include "lcd.h"
#include "spi.h"
#include"ads7818.h"
void main(void)
{
	WDTCTL = WDTPW + WDTHOLD;                 // Stop watchdog timer
	BCSCTL1 = CALBC1_1MHZ;                   // Set range
	DCOCTL = CALDCO_1MHZ;                    // Set DCO step + modulation*/
	P1DIR |=BIT5;
	SpiInit();
	LCDInit();
	__delay_cycles(50000);
	LCD_ShowString(1,1,"MSP430G2553");
	LCD_ShowString(1,2,"SPI_LCD12864");
	while(1)
	{
		printf_AD();
		__delay_cycles(50000);

	}


}

