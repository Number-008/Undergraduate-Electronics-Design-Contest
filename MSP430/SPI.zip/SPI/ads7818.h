#ifndef __ADS7818_H
#define __ADS7818_H
#include "msp430g2553.h"

u16 Read_ADS7818(void);
void printf_AD(void);

#endif
